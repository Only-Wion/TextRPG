---
id: coral_shard
type: item
tags: [sea, material]
---
A sharp coral shard used in crafting.

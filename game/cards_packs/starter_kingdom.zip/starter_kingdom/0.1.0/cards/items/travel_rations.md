---
id: travel_rations
type: item
tags: [town, consumable]
---
Dried food packs for long patrols and expeditions.

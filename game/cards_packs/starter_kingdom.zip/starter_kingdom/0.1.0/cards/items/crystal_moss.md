---
id: crystal_moss
type: item
tags: [forest, material]
---
Moss that glitters faintly and holds mana.

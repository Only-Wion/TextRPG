---
id: salt_pearl
type: item
tags: [sea, rare]
---
A pearl formed in saltwater, prized by merchants.

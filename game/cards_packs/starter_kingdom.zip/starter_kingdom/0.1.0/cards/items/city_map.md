---
id: city_map
type: item
tags: [town, utility]
---
A detailed map of the town and nearby paths.

---
id: barnacle_ore
type: item
tags: [sea, material]
---
Ore encrusted with barnacles, good for forging.

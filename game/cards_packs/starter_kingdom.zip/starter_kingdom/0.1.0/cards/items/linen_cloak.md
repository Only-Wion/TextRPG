---
id: linen_cloak
type: item
tags: [town, gear]
---
A light cloak for travel and mild weather.

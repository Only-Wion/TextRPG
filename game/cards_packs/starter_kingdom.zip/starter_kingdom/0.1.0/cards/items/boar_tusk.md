---
id: boar_tusk
type: item
tags: [forest, material]
---
A heavy tusk from a wild boar.

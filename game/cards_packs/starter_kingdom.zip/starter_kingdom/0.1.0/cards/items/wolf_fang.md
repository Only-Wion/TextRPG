---
id: wolf_fang
type: item
tags: [forest, material]
---
A sharp fang from a forest wolf.

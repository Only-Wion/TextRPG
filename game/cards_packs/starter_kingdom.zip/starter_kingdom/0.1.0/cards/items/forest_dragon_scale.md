---
id: forest_dragon_scale
type: item
tags: [forest, rare]
---
A scorched scale said to harden any armor.

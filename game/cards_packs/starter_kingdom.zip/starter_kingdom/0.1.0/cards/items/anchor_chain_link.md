---
id: anchor_chain_link
type: item
tags: [sea, material]
---
A heavy chain link from an old anchor.

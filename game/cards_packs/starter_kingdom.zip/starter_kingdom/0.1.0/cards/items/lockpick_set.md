---
id: lockpick_set
type: item
tags: [town, utility]
---
Small tools for opening simple locks quietly.

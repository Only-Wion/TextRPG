---
id: tidewood_plank
type: item
tags: [sea, material]
---
Hard driftwood used for ship repairs.

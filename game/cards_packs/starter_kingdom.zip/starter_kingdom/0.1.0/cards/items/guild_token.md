---
id: guild_token
type: item
tags: [town, key_item]
---
A token proving membership in the adventurers guild.

---
id: stormglass
type: item
tags: [sea, rare]
---
Glass formed by lightning strikes in storms.

---
id: copper_coins
type: item
tags: [town, currency]
---
A pouch of copper coins for small purchases.

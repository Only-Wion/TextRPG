---
id: abyssal_iron
type: item
tags: [sea, rare]
---
Dense metal drawn from the deep sea trenches.

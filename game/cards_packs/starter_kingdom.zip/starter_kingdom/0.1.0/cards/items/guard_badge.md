---
id: guard_badge
type: item
tags: [town, key_item]
---
An emblem that grants authority within the city guard.

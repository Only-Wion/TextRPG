---
id: leather_armor
type: item
tags: [town, armor, common]
---
Light armor offering basic protection without slowing movement.

---
id: iron_sword
type: item
tags: [town, weapon, common]
---
A sturdy iron sword used by new guards and adventurers.

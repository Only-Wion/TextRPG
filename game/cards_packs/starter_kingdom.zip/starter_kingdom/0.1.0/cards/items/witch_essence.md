---
id: witch_essence
type: item
tags: [forest, alchemy]
---
A rare essence used by the witch for advanced brews.

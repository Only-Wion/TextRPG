---
id: pirate_medallion
type: item
tags: [sea, key_item]
---
A medallion that marks dealings with pirates.

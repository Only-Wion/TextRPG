---
id: spider_silk
type: item
tags: [forest, material]
---
Tough silk used for light armor or ropes.

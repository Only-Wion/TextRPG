---
id: island_relic
type: item
tags: [sea, relic]
---
A relic found on an island, etched with unknown runes.

---
id: healing_potion
type: item
tags: [town, consumable]
---
A simple tonic that restores stamina and minor wounds.

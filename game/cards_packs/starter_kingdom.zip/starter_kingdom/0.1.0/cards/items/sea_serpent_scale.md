---
id: sea_serpent_scale
type: item
tags: [sea, material]
---
A slick scale that resists corrosion.

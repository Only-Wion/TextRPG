---
id: moonleaf_herb
type: item
tags: [forest, herb]
---
A silvery leaf used in calming potions.

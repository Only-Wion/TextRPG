---
id: glowing_mushroom
type: item
tags: [forest, herb]
---
A fungus that glows at night, useful for light potions.

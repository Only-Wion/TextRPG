---
id: ancient_seed
type: item
tags: [forest, relic]
---
A seed from the ancient tree altar, warm to the touch.

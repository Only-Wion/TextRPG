---
id: thornroot
type: item
tags: [forest, herb]
---
A bitter root valued for antidotes.

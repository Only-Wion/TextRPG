---
id: faction_forest
type: faction
tags: [faction, forest]
---
The Forest Faction is ruled by the forest dragon and its beasts.
Benefits: rare materials and access to primal magic.

---
id: faction_adventurers_guild
type: faction
tags: [faction, town]
---
The Adventurers Guild organizes expeditions and contracts.
Benefits: quest access, ranks, shared intel.

---
id: faction_sea
type: faction
tags: [faction, sea]
---
The Sea Faction is ruled by the sea dragon and island powers.
Benefits: seafaring routes and ocean relics.

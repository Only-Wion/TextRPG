---
id: faction_city_guard
type: faction
tags: [faction, town]
---
The City Guard protects citizens and enforces the law.
Benefits: patrol pay, training drills, gear access.

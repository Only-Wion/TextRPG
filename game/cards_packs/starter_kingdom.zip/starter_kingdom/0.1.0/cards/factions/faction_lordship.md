---
id: faction_lordship
type: faction
tags: [faction, town]
---
The Lordship governs the town and commands the guard.
Benefits: legal authority, city resources, political favors.

---
id: tavern_keeper_mira
type: character
tags: [town, merchant, npc]
initial_relations:
  - subject_id: tavern_keeper_mira
    relation: at
    object_id: tavern
hooks:
  - "Affinity 20+: free rumor each day."
  - "Affinity 50+: introduces hidden contacts."
---
Mira keeps the tavern running and hears every secret worth buying.

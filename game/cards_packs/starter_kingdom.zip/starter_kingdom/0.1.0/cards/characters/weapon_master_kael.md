---
id: weapon_master_kael
type: character
tags: [sea, master, npc]
initial_relations:
  - subject_id: weapon_master_kael
    relation: at
    object_id: deep_sea_isle
hooks:
  - "Affinity 20+: access to weapon training."
  - "Affinity 60+: unique legendary forging."
---
Kael crafts unmatched weapons and demands rare materials.

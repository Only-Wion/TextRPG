---
id: blacksmith_hugo
type: character
tags: [town, merchant, npc]
initial_relations:
  - subject_id: blacksmith_hugo
    relation: at
    object_id: blacksmith_shop
hooks:
  - "Affinity 20+: small discount on repairs."
  - "Affinity 50+: unlocks custom upgrades."
---
Hugo the blacksmith respects honest work and good metal.

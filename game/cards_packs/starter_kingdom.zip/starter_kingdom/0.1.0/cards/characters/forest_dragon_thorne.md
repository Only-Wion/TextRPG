---
id: forest_dragon_thorne
type: character
tags: [forest, dragon, boss]
initial_relations:
  - subject_id: forest_dragon_thorne
    relation: at
    object_id: dragon_border
hooks: []
---
Thorne rules the forest by fear and ancient fire.

---
id: tailor_ines
type: character
tags: [town, merchant, npc]
initial_relations:
  - subject_id: tailor_ines
    relation: at
    object_id: tailor_shop
hooks: []
---
Ines crafts cloaks and uniforms suited for travel and patrol.

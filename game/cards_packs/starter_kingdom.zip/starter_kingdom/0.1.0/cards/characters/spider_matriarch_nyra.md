---
id: spider_matriarch_nyra
type: character
tags: [forest, beast, leader]
initial_relations:
  - subject_id: spider_matriarch_nyra
    relation: at
    object_id: swamp_edge
hooks: []
---
Nyra spins thick webs across the swamp edge.

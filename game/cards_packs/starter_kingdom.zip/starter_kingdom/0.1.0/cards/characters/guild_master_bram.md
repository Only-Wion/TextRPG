---
id: guild_master_bram
type: character
tags: [town, guild, npc]
initial_relations:
  - subject_id: guild_master_bram
    relation: at
    object_id: adventurers_guild
hooks:
  - "Affinity 20+: access to rank B quests."
  - "Affinity 60+: rare contract and mentor favor."
---
Bram runs the adventurers guild and favors capable newcomers.

---
id: witch_elowen
type: character
tags: [forest, witch, npc]
initial_relations:
  - subject_id: witch_elowen
    relation: at
    object_id: witch_cabin
hooks:
  - "Affinity 20+: access to basic potions."
  - "Affinity 60+: rare brew and curse removal."
---
Elowen the witch studies the forest's old magic and hidden costs.

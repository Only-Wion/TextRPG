---
id: guild_adventurer_kai
type: character
tags: [town, guild, npc]
initial_relations:
  - subject_id: guild_adventurer_kai
    relation: at
    object_id: adventurers_guild
hooks: []
---
Kai is a bold adventurer who loves risky expeditions.

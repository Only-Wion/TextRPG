---
id: sea_dragon_morwen
type: character
tags: [sea, dragon, boss]
initial_relations:
  - subject_id: sea_dragon_morwen
    relation: at
    object_id: storm_belt
hooks: []
---
Morwen rules the sea depths and punishes trespassers.

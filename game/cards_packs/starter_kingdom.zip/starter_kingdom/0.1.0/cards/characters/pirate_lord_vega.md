---
id: pirate_lord_vega
type: character
tags: [sea, pirate, leader]
initial_relations:
  - subject_id: pirate_lord_vega
    relation: at
    object_id: nearshore_isle
hooks: []
---
Vega raids trade routes and bargains only from strength.

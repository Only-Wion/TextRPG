---
id: apothecary_selene
type: character
tags: [town, merchant, npc]
initial_relations:
  - subject_id: apothecary_selene
    relation: at
    object_id: apothecary
hooks:
  - "Affinity 20+: free basic tonic."
  - "Affinity 50+: unlocks advanced recipes."
---
Selene mixes remedies and studies rare herbs with care.

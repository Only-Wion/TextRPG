---
id: wolf_alpha_garruk
type: character
tags: [forest, beast, leader]
initial_relations:
  - subject_id: wolf_alpha_garruk
    relation: at
    object_id: woodland_trail
hooks: []
---
Garruk leads the forest wolves and guards hunting grounds.

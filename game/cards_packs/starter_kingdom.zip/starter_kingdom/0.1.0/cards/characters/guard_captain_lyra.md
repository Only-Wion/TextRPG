---
id: guard_captain_lyra
type: character
tags: [town, city_guard, npc]
initial_relations:
  - subject_id: guard_captain_lyra
    relation: at
    object_id: guard_barracks
hooks:
  - "Affinity 20+: access to guard drills."
  - "Affinity 50+: guard discount on gear."
---
Lyra leads the city guard with strict discipline and quiet care.

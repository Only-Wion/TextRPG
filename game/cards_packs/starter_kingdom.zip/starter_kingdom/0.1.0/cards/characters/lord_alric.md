---
id: lord_alric
type: character
tags: [town, lordship, npc]
initial_relations:
  - subject_id: lord_alric
    relation: at
    object_id: lord_manor
hooks:
  - "Affinity 30+: access to city records."
  - "Affinity 60+: special commission quest."
---
Lord Alric rules the town and values duty over profit.

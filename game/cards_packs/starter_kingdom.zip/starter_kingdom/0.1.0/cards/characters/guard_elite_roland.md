---
id: guard_elite_roland
type: character
tags: [town, city_guard, npc]
initial_relations:
  - subject_id: guard_elite_roland
    relation: at
    object_id: guard_barracks
hooks: []
---
Roland is the guard's elite fighter, respected and direct.

---
id: system_exploration
type: system
tags: [system]
---
Exploration reveals resources and quests. Forest and sea carry higher risk.
Use charisma for negotiations and intellect for puzzle clues.

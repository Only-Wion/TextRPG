---
id: system_inventory
type: system
tags: [system]
---
Inventory uses relations: player has <item_id>.
Consumables can be removed after use; equipment can grant stat bonuses.

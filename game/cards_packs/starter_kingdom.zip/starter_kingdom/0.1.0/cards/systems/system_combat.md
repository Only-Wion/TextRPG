---
id: system_combat
type: system
tags: [system]
---
Combat outcomes depend on stats, gear, and narrative positioning.
Use strength and vitality for melee, agility for dodging, intellect for tactics.

---
id: system_attributes
type: system
tags: [system]
---
Core stats: strength, agility, vitality, intellect, willpower, charisma.
Hero talent growth uses hero_talent_level and hero_talent_node.

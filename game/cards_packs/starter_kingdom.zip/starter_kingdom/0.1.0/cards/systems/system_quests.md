---
id: system_quests
type: system
tags: [system]
---
Quests list triggers, goals, rewards, and follow-ups in the card body.
Completion can update attributes, items, and affinities.

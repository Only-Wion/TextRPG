---
id: system_affinity
type: system
tags: [system]
---
Affinity is stored on the player as attributes: affinity_<npc_id> (0-100).
Increase via quests, gifts, and key choices. Thresholds unlock rewards.

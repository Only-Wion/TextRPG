---
id: quest_join_guard
type: quest
tags: [quest, town, guard]
---
Trigger: Speak to Guard Captain Lyra at guard_barracks.
Goal: Pass the basic drill and pledge service.
Reward: guard_badge, SetAttr(player.affiliation, city_guard), Affinity +10 (guard_captain_lyra).
Follow-up: quest_patrol_residential.

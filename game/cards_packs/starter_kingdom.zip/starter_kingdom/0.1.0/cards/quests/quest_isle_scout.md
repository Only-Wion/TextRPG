---
id: quest_isle_scout
type: quest
tags: [quest, sea]
---
Trigger: Obtain sailing permit.
Goal: Scout nearshore_isle and recover island_relic.
Reward: stormglass, SetAttr(player.agility, +1).
Follow-up: quest_find_weapon_master.

---
id: quest_find_weapon_master
type: quest
tags: [quest, sea]
---
Trigger: Collect rare sea materials.
Goal: Reach deep_sea_isle and meet weapon_master_kael.
Reward: access to legendary forging, Affinity +10 (weapon_master_kael).
Follow-up: none.

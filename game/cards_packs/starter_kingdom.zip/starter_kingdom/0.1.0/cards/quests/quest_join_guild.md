---
id: quest_join_guild
type: quest
tags: [quest, town, guild]
---
Trigger: Speak to Guild Master Bram at adventurers_guild.
Goal: Register and complete a simple contract.
Reward: guild_token, SetAttr(player.affiliation, adventurers_guild), Affinity +10 (guild_master_bram).
Follow-up: quest_tavern_rumors.

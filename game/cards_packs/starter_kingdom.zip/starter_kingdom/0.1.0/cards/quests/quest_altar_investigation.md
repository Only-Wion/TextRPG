---
id: quest_altar_investigation
type: quest
tags: [quest, forest]
---
Trigger: Any forest exploration.
Goal: Investigate ancient_tree_altar and return with ancient_seed.
Reward: SetAttr(player.willpower, +1), hero_talent_node = awakening_2.
Follow-up: quest_sea_permit.

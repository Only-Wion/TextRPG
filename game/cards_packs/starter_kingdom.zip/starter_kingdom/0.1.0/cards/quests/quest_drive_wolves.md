---
id: quest_drive_wolves
type: quest
tags: [quest, forest]
---
Trigger: Patrol reports or guild request.
Goal: Defeat wolf_alpha_garruk or drive the pack away.
Reward: wolf_fang, SetAttr(player.strength, +1).
Follow-up: quest_altar_investigation.

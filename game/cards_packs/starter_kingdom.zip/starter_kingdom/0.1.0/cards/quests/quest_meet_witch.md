---
id: quest_meet_witch
type: quest
tags: [quest, forest]
---
Trigger: Bring witch_essence or rare herbs.
Goal: Meet witch_elowen at witch_cabin and request a brew.
Reward: witch_essence recipe, Affinity +10 (witch_elowen).
Follow-up: quest_altar_investigation.

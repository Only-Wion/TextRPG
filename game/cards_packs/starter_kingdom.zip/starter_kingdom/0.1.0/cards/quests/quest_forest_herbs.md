---
id: quest_forest_herbs
type: quest
tags: [quest, forest]
---
Trigger: Have access to forest_gate.
Goal: Gather glowing_mushroom and crystal_moss.
Reward: SetAttr(player.intellect, +1), Affinity +5 (witch_elowen).
Follow-up: quest_meet_witch.

---
id: quest_sea_permit
type: quest
tags: [quest, sea, town]
---
Trigger: Speak to Lord Alric or Guard Captain Lyra.
Goal: Secure sailing permit at port_docks.
Reward: SetAttr(player.affiliation, sea_explorer), Affinity +5 (lord_alric).
Follow-up: quest_isle_scout.

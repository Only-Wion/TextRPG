---
id: quest_patrol_residential
type: quest
tags: [quest, town, guard]
---
Trigger: After joining the guard.
Goal: Patrol the residential_district and report incidents.
Reward: copper_coins, Affinity +5 (guard_captain_lyra).
Follow-up: quest_blacksmith_delivery.

---
id: quest_blacksmith_delivery
type: quest
tags: [quest, town]
---
Trigger: Speak to Blacksmith Hugo.
Goal: Deliver barnacle_ore or forest_dragon_scale.
Reward: gear upgrade, Affinity +10 (blacksmith_hugo).
Follow-up: quest_drive_wolves.

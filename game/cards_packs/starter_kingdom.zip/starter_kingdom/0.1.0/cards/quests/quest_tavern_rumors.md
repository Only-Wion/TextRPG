---
id: quest_tavern_rumors
type: quest
tags: [quest, town]
---
Trigger: After joining the guild.
Goal: Gather three rumors at the tavern.
Reward: city_map, Affinity +5 (tavern_keeper_mira).
Follow-up: quest_apothecary_collect.

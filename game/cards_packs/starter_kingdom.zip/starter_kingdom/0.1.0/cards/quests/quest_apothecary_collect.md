---
id: quest_apothecary_collect
type: quest
tags: [quest, town, forest]
---
Trigger: Speak to Apothecary Selene.
Goal: Collect moonleaf_herb and thornroot from forest.
Reward: healing_potion x2, Affinity +10 (apothecary_selene).
Follow-up: quest_forest_herbs.

---
id: swamp_edge
type: location
tags: [forest, swamp]
---
Wet ground and thick mist mark the edge of the swamp.

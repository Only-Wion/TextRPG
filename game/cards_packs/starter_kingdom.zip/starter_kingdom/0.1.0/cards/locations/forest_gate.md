---
id: forest_gate
type: location
tags: [forest, border]
---
The last safe checkpoint before the wild forest begins.

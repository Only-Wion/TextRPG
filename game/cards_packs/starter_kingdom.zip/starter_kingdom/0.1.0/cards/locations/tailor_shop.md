---
id: tailor_shop
type: location
tags: [town, craft]
---
A bright shop for cloaks, uniforms, and travel gear.

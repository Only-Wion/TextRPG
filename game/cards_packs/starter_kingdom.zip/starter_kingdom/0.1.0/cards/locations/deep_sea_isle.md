---
id: deep_sea_isle
type: location
tags: [sea, legendary]
---
A far island where the weapon master forges impossible blades.

---
id: storm_belt
type: location
tags: [sea, danger]
---
Raging winds and lightning walls guard the deep sea routes.

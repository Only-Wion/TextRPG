---
id: ancient_tree_altar
type: location
tags: [forest, sacred]
---
An immense tree with carved runes and a silent altar.

---
id: nearshore_isle
type: location
tags: [sea, island]
---
A small island with hidden coves and shallow reefs.

---
id: dragon_border
type: location
tags: [forest, danger]
---
Scorched trees and massive claw marks signal the dragon's reach.

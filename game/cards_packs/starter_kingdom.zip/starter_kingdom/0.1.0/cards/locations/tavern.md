---
id: tavern
type: location
tags: [town, social, inn]
---
A warm tavern where rumors and contracts change hands.

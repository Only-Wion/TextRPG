---
id: woodland_trail
type: location
tags: [forest, path]
---
A winding trail under dense canopy, rich with tracks and whispers.

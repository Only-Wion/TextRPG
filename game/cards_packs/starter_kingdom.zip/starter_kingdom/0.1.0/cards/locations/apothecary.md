---
id: apothecary
type: location
tags: [town, medicine]
---
Shelves of herbs and tonics line the walls, tended by a calm healer.

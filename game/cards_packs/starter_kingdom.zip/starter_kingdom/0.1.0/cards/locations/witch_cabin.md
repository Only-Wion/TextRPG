---
id: witch_cabin
type: location
tags: [forest, witch]
---
A secluded cabin surrounded by herbs and faint green light.

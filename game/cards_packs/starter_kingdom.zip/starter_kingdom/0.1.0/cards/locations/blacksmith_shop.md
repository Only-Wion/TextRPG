---
id: blacksmith_shop
type: location
tags: [town, craft]
---
A roaring forge where weapons and armor are repaired and improved.

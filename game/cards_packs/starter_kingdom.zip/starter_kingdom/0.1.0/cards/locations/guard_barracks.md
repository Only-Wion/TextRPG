---
id: guard_barracks
type: location
tags: [town, guard]
---
Training yards and armories for the city guard.

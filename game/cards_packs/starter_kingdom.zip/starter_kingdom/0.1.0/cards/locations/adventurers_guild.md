---
id: adventurers_guild
type: location
tags: [town, guild]
---
The guild hall where adventurers register, rest, and seek work.

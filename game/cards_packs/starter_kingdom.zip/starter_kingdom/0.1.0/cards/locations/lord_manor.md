---
id: lord_manor
type: location
tags: [town, lordship]
---
The lord's manor stands over the town, guarded and orderly.

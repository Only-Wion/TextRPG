---
id: residential_district
type: location
tags: [town, housing]
---
Modest homes and narrow lanes where townsfolk live.

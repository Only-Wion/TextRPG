# Starter Kingdom Pack

A ready-to-play pack featuring a town, a forest ruled by a dragon, and a sea ruled by a dragon.

Included:
- 18 locations (town, forest, sea)
- 16 characters (town NPCs, forest leaders, sea leaders)
- 30 items (10 town, 10 forest, 10 sea)
- 5 factions, 6 system cards, 13 quests
- Overlay ops to initialize player stats and affinities
